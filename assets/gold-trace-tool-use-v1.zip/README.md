# Gold Trace Tool-Use Starter v1.0.0

Eight small, public practice cases for checking decisions around tool results.
Each case supplies a policy and observations. The task is to choose the correct
next action. Includes one verified-completion control as well as failure cases.

## Try it

1. Give a model only `export/public.inputs.jsonl` (one case at a time or as a batch).
2. Save its answers as JSONL with exactly `id` and `action` fields.
3. Run `python3 score.py predictions.jsonl` from this folder.

Example prediction: `{"id":"GT-001","action":"read_current_record"}`.
The scorer requires all eight IDs exactly once. Wrong decisions return exit 1;
invalid, missing, duplicate or unknown IDs return exit 2. All correct returns 0.
It uses only the Python standard library.

Smoke-test the scorer with:
`python3 score.py examples/reference-predictions.jsonl`.
That file contains the expected answers; it is not a model evaluation.

## Files

- `export/public.inputs.jsonl`: model-facing tasks, without answers.
- `answers/public.answers.jsonl`: expected decisions and rationales.
- `canonical/golden.jsonl`: complete reviewed records for inspection.
- `examples/gt-004.json`: the denied-action example with its expected decision.
- `evidence/`: factory verification reports, source manifest pins and promotion projection.
- `DATASET_CARD.md`: origin, review, method and limitations.
- `FILE_MANIFEST.tsv`: sizes and SHA-256 hashes for release files.

Data: CDLA-Permissive-2.0 (`LICENSE.md`). The small original scorer is MIT-licensed
(`SCORER_LICENSE.txt`). No private conversation text or private source mappings
are included.
