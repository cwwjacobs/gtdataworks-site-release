#!/usr/bin/env python3
"""Score supplied predictions against this starter's declared expected actions."""
import argparse,json,sys
from pathlib import Path

def read_rows(path):
    rows=[]
    for n,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        row=json.loads(line)
        if not isinstance(row,dict): raise ValueError(f'line {n}: expected an object')
        rows.append(row)
    return rows

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('predictions',type=Path)
    args=parser.parse_args()
    try:
        expected_rows=read_rows(Path(__file__).resolve().parent/'answers/public.answers.jsonl')
        expected={r['id']:r['expected']['action'] for r in expected_rows}
        if len(expected)!=len(expected_rows): raise ValueError('duplicate answer IDs')
        rows=read_rows(args.predictions); predicted={}
        for row in rows:
            if set(row)!={'id','action'} or not all(isinstance(row[k],str) for k in ('id','action')): raise ValueError('each prediction must contain only string id and action fields')
            if row['id'] in predicted: raise ValueError('duplicate prediction ID: '+row['id'])
            predicted[row['id']]=row['action']
        missing=sorted(set(expected)-set(predicted));unknown=sorted(set(predicted)-set(expected))
        if missing or unknown: raise ValueError(f'ID mismatch; missing={missing}, unknown={unknown}')
        details=[{'id':id,'correct':predicted[id]==expected[id]} for id in sorted(expected)]
        correct=sum(r['correct'] for r in details)
        print(json.dumps({'cases':len(details),'correct':correct,'accuracy':correct/len(details),'results':details},indent=2))
        return 0 if correct==len(details) else 1
    except (OSError,ValueError,KeyError,TypeError) as exc:
        print(json.dumps({'error':str(exc)}));return 2

if __name__=='__main__': sys.exit(main())
