# Dataset card: Gold Trace Tool-Use Starter

Version: 1.0.0. Eight synthetic decision tasks, one public practice split.

## Origin and review

The task ideas were abstracted from eight reviewed technical messages in an
operator-authorized conversation archive. All policies, fixture facts, choices
and explanations in this release are newly authored neutral scenarios. No
verbatim conversation excerpts, private source mappings, personal identifiers,
machine paths, or credentials are included.
Public provenance pins the synthetic fixture bytes. Source-to-message mappings
remain private. Review was performed by AI assistants, including an independent
reviewer and the publishing assistant; no human review is claimed.

## Method

A Codex CLI run using gpt-6.1-sol selected the eight actions from supplied model
inputs, without the answer file. One initial wording ambiguity was repaired
before release and the revised inputs were rerun. This is curation, not a blind
held-out benchmark result. The observed decisions are retained under evidence.

The decisions were imported through the supported file-replay generator of
GTD Dataset Factory Core SeedRunner at commit
be548beed641e895fe6edf37dd854d93c071e68d. Its deterministic exact-match oracle
accepted all eight declared actions. A second file replay matched the candidate
outputs and oracle outcomes. Both manifests and receipt structures verified. Factory execution and replay used an injected deterministic clock. Public validation summaries omit timestamps and make no wall-clock chronology or duration claim. Raw factory runs remain private because provider metadata records local paths. The public evidence reports include their manifest hashes; they do not claim to distribute the complete raw runs.
The factory's promotion policy returned Gold after evidence, provenance, privacy,
replay and integrity checks. Promotion is a separate projection; original run
records remain unchanged as Silver, as required by the runtime contract.

## What the checks establish

Gold here means that the retained decisions passed the factory's declared
checks and replayed against the supplied expected actions. The expected actions
were independently reviewed against the stated policies. Hashes detect changes
relative to the included manifests; they are not signatures or external audit.

These are simple decision tasks over supplied observations. They do not execute
tools, measure multi-step agent behavior, establish model robustness, or certify
general safety. The small public set is suitable for inspection and starter
regressions, not for claims about held-out performance. Public answers permit
contamination; keep them out of model context when trying the tasks.

## Coverage

Stale revision; missing evidence; authority of captured content; denied action;
pending commit; timeout versus termination; duplicate side effects; verified
completion. All fixture identifiers are synthetic. The dataset is English only.

## License

CDLA-Permissive-2.0, matching the factory's existing public dataset release.
New scenario text and fixture data are released by GTDataworks. The repository's
proprietary factory implementation is not included. The original scorer has a
separate MIT license.
